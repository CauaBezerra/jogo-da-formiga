var formiga, formigaImg;
var chocolate,chocolateImg;
var barreira1,barreira2,barreira3,barreira4;
var esquerda,direita,baixo,cima;
var pontuação = 0;
var obstaculo;
var florIMG, folhaIMG, pedraIMG;
var grupoObstaculos;
var arvore, arvoreIMG;

function preload(){
  formigaImg = loadImage("assets/formiga.png");

  chocolateImg = loadImage("assets/Barra-chocolate.png");

  florIMG = loadImage("assets/flor.png");
  pedraIMG = loadImage("assets/pedra.png");
  folhaIMG = loadImage("assets/folha.png");

  arvoreIMG = loadImage("assets/arvore.png");
}

function setup(){

  for(var i = -50;i<1000;i=i+200){
    arvore = createSprite(i,-75,20,20);
    arvore.addImage(arvoreIMG);
    arvore.scale = 0.5;
}
for(var i = -50;i<1000;i=i+200){
  arvore = createSprite(i,900,20,20);
  arvore.addImage(arvoreIMG);
  arvore.scale = 0.5;
}
for(var i = -50;i<1000;i=i+200){
  arvore = createSprite(-75,i,20,20);
  arvore.addImage(arvoreIMG);
  arvore.scale = 0.5;
}
for(var i = -50;i<1000;i=i+200){
arvore = createSprite(900,i,20,20);
arvore.addImage(arvoreIMG);
arvore.scale = 0.5;
}

  formiga = createSprite(200,200,10,10);
  formiga.addImage(formigaImg);
  formiga.scale = 0.15;

  grupoObstaculos = new Group();

  barreira1 = createSprite(20,400,20,780);
  barreira2 = createSprite(400,20,780,20);
  barreira3 = createSprite(800,400,20,780);
  barreira4 = createSprite(410,800,800,20);
  
  for( var i = 0; i < 7; i++){
    obstaculos();
  }
  doce();
}

function draw() {
  
  background("green");

  
  fill("black");
  textSize(20);
  text("pontuação: " + pontuação,formiga.x - 170,formiga.y - 150);

  if(keyDown("up") && cima === true){
    formiga.y += -3;
  }
  if(keyDown("left") && esquerda === true){
    formiga.x += -3;
  }
  if(keyDown("down") && baixo === true){
    formiga.y += 3;
  }
  if(keyDown("right") && direita === true){
    formiga.x += 3;
  }

  if(formiga.isTouching(barreira1)){
    esquerda = false;
  }else{
    esquerda = true;
  }
  if(formiga.isTouching(barreira2)){
    cima = false;
  }else{
    cima = true;
  }
  if(formiga.isTouching(barreira3)){
    direita = false;
  }else{
    direita = true;
  }
  if(formiga.isTouching(barreira4)){
    baixo = false;
  }else{
    baixo = true;
  }


  if(formiga.isTouching(grupoObstaculos) && keyDown("left")){
    formiga.x += 10; 
    esquerda = false;
  }
  if(formiga.isTouching(grupoObstaculos) && keyDown("up")){
    formiga.y += 10; 
    cima = false;
  }
  if(formiga.isTouching(grupoObstaculos) && keyDown("right")){
    formiga.x += -10; 
    direita = false;
  }
  if(formiga.isTouching(grupoObstaculos) && keyDown("down")){
    formiga.y += -10; 
    baixo = false;
  }

  if(formiga.isTouching(chocolate)){
    pontuação += 1;
    chocolate.x = Math.round(random(40,760));
    chocolate.y = Math.round(random(40,760));
    grupoObstaculos.destroyEach();
    for( var i = 0; i < 7; i++){
      obstaculos();
    }
  }

  if(chocolate.isTouching(grupoObstaculos)){
    chocolate.x = Math.round(random(40,760));
    chocolate.y = Math.round(random(40,760));
    grupoObstaculos.destroyEach();
    for( var i = 0; i < 7; i++){
      obstaculos();
    }
  }

  barreira1.visible = false;
  barreira2.visible = false;
  barreira3.visible = false;
  barreira4.visible = false;

  camera.position.x = formiga.position.x;
  camera.position.y = formiga.position.y;

        drawSprites();
}

function doce(){
  chocolate = createSprite(200,300,10,10);
  chocolate.addImage(chocolateImg);
  chocolate.scale = 0.3;
  chocolate.x = Math.round(random(40,760));
  chocolate.y = Math.round(random(40,760));
  
}

function obstaculos(){
  obstaculo = createSprite(100,100,7,7);
  obstaculo.y = Math.round(random(120,680));
  obstaculo.x = Math.round(random(120,680));

  var obs = Math.round(random(1,3));
  switch(obs){
    case 1: obstaculo.addImage(florIMG);
    obstaculo.scale = 0.5;
    obstaculo.depth = 3;
    break;
    case 2: obstaculo.addImage(folhaIMG);
    obstaculo.scale = 0.3;
    obstaculo.depth = 2;
    break;
    case 3: obstaculo.addImage(pedraIMG);
    obstaculo.scale = 0.4;
    obstaculo.depth = 1;
    default:break;
  }

  grupoObstaculos.add(obstaculo);

}
